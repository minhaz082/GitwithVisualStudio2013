﻿
function BindEvent() {

    $('#divManualSerial').hide();
    $('#divCustomerCorporateID').hide();
    $('#divCustomerEmail').hide();
    $('#divCustAddress').hide();
    $('#divAmountCurrency').hide();
    $('#divFinalComments').hide();
    $('#divRouteDropDownList').hide();
    $('#divSelectRoute').hide();
    $('#divPnrFees').hide();
    $('#divPNR').hide();
    $('#divFees').hide();
    $('#divFlightNoDate').hide();
    $('#divflightNo').hide();
    $('#divFlightDate').hide();
    $('#divQuantityWeight').hide();
    $('#divQuantity').hide();
    $('#divWeight').hide();
    $('#divTagReference').hide();
    $('#divTagNo').hide();
    $('#divReferenceNo').hide();
    $('#divBusNoTime').hide();
    $('#divBusNo').hide();
    $('#divBusStartTime').hide();
    $('#divPurposeRemarksHead').hide();
    $('#divRemarksPurpose').hide();
    $('#divRouteTextBoxes').hide();
    $('#divRpoteStartText').hide();
    $('#divRouteEndText').hide();

    $('#divBankCardType').hide();
    $('#divCardNoFull').hide();
    $('#divChequeNoFull').hide();
    $('#divBcashMobileFull').hide();
    $('#divMBbankMobile').hide();

    $('#divCardType').hide();
    $('#divCardNo').hide();
    $('#divBankName').hide();
    $('#divChequeNo').hide();
    $('#divBcashMobile').hide();
    $('#divMBbank').hide();
    $('#divMBMobile').hide();
    $('#divTransactionID').hide();
    $('#divReceiverHead').hide();
    $('#divCargoReceiver').hide();
    $("#divCustomerName").hide();
    $("#divCustomerMobile").hide();
    $('#lblRedStar').hide();
    $('#lblRedStarr').hide();
    $('#divMCDStatus').hide();
    $('#divMCDSerial').hide();
    $('#divStartEndDateRange').hide();

    $('#divBankName').show();
    $('#divDepositSlipNo').show();
    $('#divDepositDate').show();
    $('#divDepositBy').show();
    $('#divDepositBankCharge').show();
    $('#divReceivedBy').hide();
    $('#divReceiverPhone').hide();
    $('#divReceiverEmpID').hide();
    $('#divReceivedDate').hide();
    $('#divBusPassengerFare').hide();


    //topup deposit
    $('#divReceivedBy').show();
    $('#divReceiverPhone').show();
    $('#divReceiverEmpID').show();
    $('#divReceivedDate').show();
    $('#divDepositAmount').show();
    $('#divRemarks').show();
    $('#divBankName').hide();
    $('#divBankBranch').hide();
    $('#divDepositSlipNo').hide();
    $('#divDepositDate').hide();
    $('#divDepositBy').hide();
    $('#divDepositBankCharge').hide();


    $('#ddlPurposeOfCollection').change(function () {
        GetddlPurposeOfCollection()
    });

    $('#ddlRouteStart').change(function () {
        CheckforSameENd()
    });

    $('#ddlBusStartRoute').change(function () {
        CheckforSameBusENd()
    });

    $('#ddlBusEndRoute').change(function () {
        CheckforSameBusStart()
    });

    $('#ddlRouteEnd').change(function () {
        CheckforSameStart()
    });

    $('#ddlDepositMode').change(function () {
        GetDepositModewiseField()
    });

    $('#checkMeOut').click(function () {
        GetCheckBoxSelect()
    });

    $('#checkCorporateID').click(function () {
        GetCorporateIDSelect()
    });

    $('#checkCustomerEmail').click(function () {
        GetCustomerEmailSelect()
    });

    $('#checkCustomerAddress').click(function () {
        GetCustomerAddressBox()
    });

    $('#selectStrtEndRoute').click(function () {
        GetstartEndRouteDropDown()
    });

    $('#selectTagReffNo').click(function () {
        GetTagReffTextBox()
    });

    $('#selectTagReffNoEBT').click(function () {
        GetTagReffEBTtextBox()
    });

    $('#selectReceiverInfo').click(function () {
        GetReceiverInfoTextBox()
    });

    $('#selectCurrency').click(function () {
        GetCurrencyDropDown()
    });

    $('#addFinalRemarks').click(function () {
        GetFinalRemarksTextBox()
    });
    $('#chkStatus').click(function () {
        GetMCDStatusRadioButton()
    });
    $('#chkSerial').click(function () {
        GetMCDSerialTextBox()
    });
    $('#chkDateRange').click(function () {
        GetDateRangeDiv()
    });

    $('#chkAmountInWord').click(function () {
        var ischecked = $(this).is(':checked');
        if (ischecked) {
            GetPaidAmountInWord()
        }
        else {
            $('#lblAmountInWord').text('');
        }
    });

    $('#ddlModeOfPayment').change(function () {
        GetddlModeOfPayment()
    });

    $('#txtAmount').on('input', function () {
        var textValue = $(this).val();
        $('#txtWaiver').val(0.0);
        $('#txtTax').val(0.0);
        $('#txtPaidAmount').val(textValue);
        var paidtextbox = textValue.toString();
        //var amt = addCommas(paidtextbox);
        //alert(amt)



        $('#txtPaidAmount').text(paidtextbox); // paidamount is filled with amount           

        $('#hdnAmountInWord').val(parseInt($('#txtPaidAmount').val(), 10));
        $('#hiddenInWord').text(paidtextbox);
        $('#hiddenInWord').val(parseInt($('#txtPaidAmount').val(), 10));



        //function addCommas(nStr) {
        //    nStr += '';
        //    x = nStr.split('.');
        //    x1 = x[0];
        //    x2 = x.length > 1 ? '.' + x[1] : '';
        //    var rgx = /(\d+)(\d{3})/;
        //    while (rgx.test(x1)) {
        //        x1 = x1.replace(rgx, '$1' + ',' + '$2');
        //    }
        //    return x1 + x2;
        //}
        //function addCommas(n) {
        //    var s = "",
        //        r;

        //    while (n) {
        //        r = n % 1000;
        //        s = r + s;
        //        n = (n - r) / 1000;
        //        s = (n ? "," : "") + s;
        //    }

        //    return s;
        //}
        function addCommas(nStr) {
            nStr += '';
            x = nStr.split('.');
            x1 = x[0];
            x2 = x.length > 1 ? '.' + x[1] : '';
            var rgx = /(\d+)(\d{3})/;
            while (rgx.test(x1)) {
                x1 = x1.replace(rgx, '$1' + ',' + '$2');
            }
            return x1 + x2;
        }


    });

    $('#txtWaiver').on('input', function () {
        var waiver = $(this).val();
        var waiverInt = parseInt($(this).val(), 10);
        if ($('#txtWaiver').text == "" || isNaN(waiverInt)) {
            $('#txtWaiver').text("0");
            $('#txtWaiver').val(0.0);
            waiver = parseInt('0', 10);
        }
        var amount = parseInt($('#txtAmount').val(), 10);
        var tax = parseInt($('#txtTax').val(), 10);
        var paidAmount = (amount - waiver) + tax;
        $('#txtPaidAmount').val(paidAmount);
        var paidtextbox = paidAmount.toString();
        $('#txtPaidAmount').text(paidtextbox);  //paidamount is filled with calculation 
        $('#hiddenInWord').text(paidtextbox);
        $('#hiddenInWord').val(parseInt($('#txtPaidAmount').val(), 10));
    });

    $('#txtTax').on('input', function () {
        var tax = $(this).val();
        var taxx = parseInt($(this).val(), 10);
        if (isNaN(taxx) || taxx < 0) {
            taxx = parseInt('0', 10);
            $('#txtTax').val(0.0);
            $('#txtTax').text("0");
        }

        var amount = parseInt($('#txtAmount').val(), 10);
        var waiver = parseInt($('#txtWaiver').val(), 10);
        var paidAmount = (amount - waiver) + taxx;
        $('#txtPaidAmount').val(paidAmount);

        var paidtextbox = paidAmount.toString();
        $('#txtPaidAmount').text(paidtextbox);
        $('#hdnAmountInWord').val(parseInt($('#txtPaidAmount').val(), 10));
        $('#hiddenInWord').text(paidtextbox);
        $('#hiddenInWord').val(parseInt($('#txtPaidAmount').val(), 10));
    });

    $('#txtAmountUpdate').on('input', function () {
        var textValue = $(this).val();
        $('#txtWaiverUpdate').val(0);
        $('#txtTaxUpdate').val(0);
        $('#txtPaidAmountUpdate').val(textValue);
        var paidtextbox = textValue.toString();
        $('#txtPaidAmountUpdate').text(paidtextbox);
        $('#hdnAmountInWord').val(parseInt($('#txtPaidAmountUpdate').val(), 10));
        $('#hiddenInWord').text(paidtextbox);
        $('#hiddenInWord').val(parseInt($('#txtPaidAmountUpdate').val(), 10));
    });

    $('#txtWaiverUpdate').on('input', function () {
        var waiver = $(this).val();
        var amount = parseInt($('#txtAmountUpdate').val(), 10);
        var tax = parseInt($('#txtTaxUpdate').val(), 10);
        var paidAmount = (amount - waiver) + tax;
        $('#txtPaidAmountUpdate').val(paidAmount);

        var paidtextbox = paidAmount.toString();
        $('#txtPaidAmountUpdate').text(paidtextbox);
        $('#hdnAmountInWord').val(parseInt($('#txtPaidAmountUpdate').val(), 10));
        $('#hiddenInWord').text(paidtextbox);
        $('#hiddenInWord').val(parseInt($('#txtPaidAmountUpdate').val(), 10));
    });

    $('#txtTaxUpdate').on('input', function () {
        var tax = $(this).val();
        var taxx = parseInt($(this).val(), 10);
        var amount = parseInt($('#txtAmountUpdate').val(), 10);
        var waiver = parseInt($('#txtWaiverUpdate').val(), 10);
        var paidAmount = (amount - waiver) + taxx;
        $('#txtPaidAmountUpdate').val(paidAmount);

        var paidtextbox = paidAmount.toString();
        $('#txtPaidAmountUpdate').text(paidtextbox);
        $('#hdnAmountInWord').val(parseInt($('#txtPaidAmountUpdate').val(), 10));
        $('#hiddenInWord').text(paidtextbox);
        $('#hiddenInWord').val(parseInt($('#txtPaidAmountUpdate').val(), 10));
    });

    $('#txtWeight').on('input', function () {
        var textValue = $(this).val();
        var purposeID = $("#ddlPurposeOfCollection").val()

        if (purposeID == "mail_courier") {
            if (textValue > 1) {
                alert("Mail/Courier Waight can not be more than 1 Kg.")
                $('#txtWeight').val("");
            }
            else {
            }
        }
    });

    $('#topup').on('show.bs.modal', function (e) {

        var autoserial = $('#lblautoIDhidden').text();
        var manualSerial = $('#txtManualSerial').val();
        var mcdDate = $('#txtMCDdate').val();
        var stationOffice = $("#ddlStationOffice option:selected").text();
        var CustomerName = $('#txtCustomer').val();
        var corporateID = $('#txtCorporateID').val();
        var CusMobile = $('#TxtCustomerMobile').val();
        var CusEmail = $('#txtEmail').val();
        var CusAddress = $('#txtAddress').val();
        var collectionPurpose = $("#ddlPurposeOfCollection option:selected").text();
        var PNR = $('#txtPNR').val();
        var fees = $('#txtFees').val();
        var flightNo = $('#txtFlightNo').val();
        var flightDate = $('#txtFlightDate').val();
        var Quantity = $('#txtQuantity').val();
        var weight = $('#txtWeight').val();
        var tagNo = $('#txttagNo').val();
        var referrence = $('#txtReferenceNo').val();
        var busNo = $('#txtBusNo').val();
        var busStartTime = $('#txtButStartTime').val();
        var otherRemarks = $('#txtOtherRemarks').val();

        //var routeStartText = $('#txtRouteStart').val();
        //var routeEndText = $('#txtRouteEnd').val();

        var routeStartText = $("#ddlBusStartRoute option:selected").text();
        var routeEndText = $("#ddlBusEndRoute option:selected").text();

        var routeStartDDL = $("#ddlRouteStart option:selected").text();
        var routeEndDDL = $("#ddlRouteEnd option:selected").text();

        var ModeOFPayment = $("#ddlModeOfPayment option:selected").text();
        var cardType = $("#ddlCardType option:selected").text();
        var bankName = $('#txtBankName').val();
        var cardNO1 = $('#txtCardNo1').val();   //txtCardNo1  txtCardNo2  txtCardNo3  txtCardNo4
        var cardNo4 = $('#txtCardNo4').val();
        //var cardNOTotal = cardNO1 + "-XXXX-XXXX-" + cardNo4
        var cardNo = cardNO1 + "-XXXX-XXXX-" + cardNo4;
        var chequeNo = $('#txtChequeNo').val();
        var bcashMobile = $('#txtBcashMobile').val();
        var MBbank = $('#txtMBBankname').val();
        var MBmobile = $('#txtMBMobile').val();
        var TracsactionID = $('#txtTransactionID').val();
        var currency = $("#ddlCurrency option:selected").text();
        var amount = $('#txtAmount').val();
        var waiver = $('#txtWaiver').val();
        var tax = $('#txtTax').val();
        var paidAmount = $('#txtPaidAmount').val();
        var amountInWord = $('#lblAmountInWord').text();
        var remarks = $('#txtRemarks').val();
        var cargoReceiver = $('#txtCargoReceiver').val();
        var CustomerZone = $('#txtZone').val();
        var CustomerCountry = $('#txtCountryName').val();

        //Pass Values in modal
        if (manualSerial.length <= 0) {
            $('#divmanual').hide();
        }
        else {
            $('#divmanual').show();
        }

        //////////////////////////////////////////////////////////
        var stationOfficeID = $("#ddlStationOffice").val()

        if (stationOfficeID == 0) {
            $('#StationOffice').html("");
        }
        else {
            $('#StationOffice').html(stationOffice);
        }

        //////////////////////////////////////////////////////////////////
        var purposeID = $("#ddlPurposeOfCollection").val()
        if (purposeID == 'sl') {
            $('#CollectionPurpose').html("");
        }
        else {
            $('#CollectionPurpose').html(collectionPurpose);
        }

        ////////////////////////////////////////////////

        var purposeID = $("#ddlPurposeOfCollection").val()
        if (purposeID == "tkt_Issu") {

            $('#divPNRNO').show();
            $('#divFeesAmt').hide();
            $('#divFlightNo').hide();
            $('#divFlightDateModal').hide();
            $('#divQuantityModal').hide();
            $('#divWeightModal').hide();
            $('#divTagModal').hide();
            $('#divReffrenceModal').hide();
            $('#divBusNoModal').hide();
            $('#divBusTimeModal').hide();
            $('#divOtherRemarkModal').hide();
            $('#divCargoReceiverModal').hide();
            $('#divRouteStartModal').hide();
            $('#divRouteEndModal').hide();
            //$('#CollectionPurpose').html(collectionPurpose);
        }
        else if (purposeID == "tkt_Exchange") {

            $('#divPNRNO').show();
            $('#divFeesAmt').hide();
            $('#divFlightNo').hide();
            $('#divFlightDateModal').hide();
            $('#divQuantityModal').hide();
            $('#divWeightModal').hide();
            $('#divTagModal').hide();
            $('#divReffrenceModal').hide();
            $('#divBusNoModal').hide();
            $('#divBusTimeModal').hide();
            $('#divOtherRemarkModal').hide();
            $('#divCargoReceiverModal').hide();
            $('#divRouteStartModal').hide();
            $('#divRouteEndModal').hide();
            //$('#CollectionPurpose').html(collectionPurpose);

        }
        else if (purposeID == "mail_courier") {
            $('#divPNRNO').hide();
            $('#divFeesAmt').hide();
            $('#divFlightNo').show();
            $('#divFlightDateModal').show();
            $('#divQuantityModal').show();
            $('#divWeightModal').show();
            $('#divTagModal').show();
            $('#divReffrenceModal').show();
            $('#divBusNoModal').hide();
            $('#divBusTimeModal').hide();
            $('#divOtherRemarkModal').hide();
            $('#divCargoReceiverModal').show();
            $('#divRouteStartModal').hide();
            $('#divRouteEndModal').hide();
            //$('#CollectionPurpose').html(collectionPurpose);
        }
        else if (purposeID == "ebt") {
            $('#divPNRNO').show();
            $('#divFeesAmt').show();
            $('#divFlightNo').show();
            $('#divFlightDateModal').show();
            $('#divQuantityModal').hide();
            $('#divWeightModal').show();
            $('#divTagModal').show();
            $('#divReffrenceModal').show();
            $('#divBusNoModal').hide();
            $('#divBusTimeModal').hide();
            $('#divOtherRemarkModal').hide();
            $('#divCargoReceiverModal').hide();
            $('#divRouteStartModal').hide();
            $('#divRouteEndModal').hide();
            //$('#CollectionPurpose').html(collectionPurpose);
        }
        else if (purposeID == "cargo") {
            $('#divPNRNO').hide();
            $('#divFeesAmt').show();
            $('#divFlightNo').show();
            $('#divFlightDateModal').show();
            $('#divQuantityModal').hide();
            $('#divWeightModal').show();
            $('#divTagModal').show();
            $('#divReffrenceModal').show();
            $('#divBusNoModal').hide();
            $('#divBusTimeModal').hide();
            $('#divOtherRemarkModal').hide();
            $('#divCargoReceiverModal').show();
            $('#divRouteStartModal').hide();
            $('#divRouteEndModal').hide();
            //$('#CollectionPurpose').html(collectionPurpose);
        }
        else if (purposeID == "bus_tkt") {
            $('#divPNRNO').hide();
            $('#divFeesAmt').hide();
            $('#divFlightNo').hide();
            $('#divFlightDateModal').hide();
            $('#divQuantityModal').hide();
            $('#divWeightModal').hide();
            $('#divTagModal').hide();
            $('#divReffrenceModal').hide();
            $('#divBusNoModal').show();
            $('#divBusTimeModal').show();
            $('#divRouteStartModal').show();
            $('#divRouteEndModal').show();
            $('#divOtherRemarkModal').hide();
            $('#divCargoReceiverModal').hide();
            //$('#CollectionPurpose').html(collectionPurpose);
        }
        else if (purposeID == "other") {
            $('#divPNRNO').hide();
            $('#divFeesAmt').hide();
            $('#divFlightNo').hide();
            $('#divFlightDateModal').hide();
            $('#divQuantityModal').hide();
            $('#divWeightModal').hide();
            $('#divTagModal').hide();
            $('#divReffrenceModal').hide();
            $('#divBusNoModal').hide();
            $('#divBusTimeModal').hide();
            $('#divOtherRemarkModal').show();
            $('#divCargoReceiverModal').hide();
            $('#divRouteStartModal').hide();
            $('#divRouteEndModal').hide();
            //$('#CollectionPurpose').html(collectionPurpose);
        }
        else {
            $('#divPNRNO').hide();
            $('#divFeesAmt').hide();
            $('#divFlightNo').hide();
            $('#divFlightDateModal').hide();
            $('#divQuantityModal').hide();
            $('#divWeightModal').hide();
            $('#divTagModal').hide();
            $('#divReffrenceModal').hide();
            $('#divBusNoModal').hide();
            $('#divBusTimeModal').hide();
            $('#divOtherRemarkModal').hide();
            //$('#CollectionPurpose').html();
            $('#divCargoReceiverModal').hide();
            $('#divRouteStartModal').hide();
            $('#divRouteEndModal').hide();
        }

        /////////////////////////////////////////////////////////////////

        var paymentModeID = $("#ddlModeOfPayment").val()

        if (paymentModeID == "cash") {
            $('#divCardTypeM').hide();
            $('#divCreditCardM').hide();
            $('#divBankNameM').hide();
            $('#divChequeNoM').hide();
            $('#divBCashNo').hide();
            $('#divMBBankM').hide();
            $('#divMBMobileM').hide();
            $('#divMBTransactionIDM').hide();
            $('#ModeOFPaymentM').html(ModeOFPayment);
        }
        else if (paymentModeID == "card") {
            $('#divCardTypeM').show();
            $('#divCreditCardM').show();
            $('#divBankNameM').show();
            $('#divChequeNoM').hide();
            $('#divBCashNo').hide();
            $('#divMBBankM').hide();
            $('#divMBMobileM').hide();
            $('#divMBTransactionIDM').show();
            $('#ModeOFPaymentM').html(ModeOFPayment);
        }
        else if (paymentModeID == "cheque") {
            $('#divCardTypeM').hide();
            $('#divCreditCardM').hide();
            $('#divBankNameM').show();
            $('#divChequeNoM').show();
            $('#divBCashNo').hide();
            $('#divMBBankM').hide();
            $('#divMBMobileM').hide();
            $('#divMBTransactionIDM').hide();
            $('#ModeOFPaymentM').html(ModeOFPayment);
        }
        else if (paymentModeID == "bCash") {
            $('#divCardTypeM').hide();
            $('#divCreditCardM').hide();
            $('#divBankNameM').hide();
            $('#divChequeNoM').hide();
            $('#divBCashNo').show();
            $('#divMBBankM').hide();
            $('#divMBMobileM').hide();
            $('#ModeOFPaymentM').html(ModeOFPayment);
        }
        else if (paymentModeID == "m_banking") {
            $('#divCardTypeM').hide();
            $('#divCreditCardM').hide();
            $('#divBankNameM').hide();
            $('#divChequeNoM').hide();
            $('#divBCashNo').hide();
            $('#divMBBankM').show();
            $('#divMBMobileM').show();
            $('#divMBTransactionIDM').show();
            $('#ModeOFPaymentM').html(ModeOFPayment);
        }
        else if (paymentModeID == "invoice") {
            $('#divCardTypeM').hide();
            $('#divCreditCardM').hide();
            $('#divBankNameM').hide();
            $('#divChequeNoM').hide();
            $('#divBCashNo').hide();
            $('#divMBBankM').hide();
            $('#divMBMobileM').hide();
            $('#divMBTransactionIDM').hide();
            $('#ModeOFPaymentM').html(ModeOFPayment);
        }
        else if (paymentModeID == "others") {
            $('#divCardTypeM').hide();
            $('#divCreditCardM').hide();
            $('#divBankNameM').hide();
            $('#divChequeNoM').hide();
            $('#divBCashNo').hide();
            $('#divMBBankM').hide();
            $('#divMBMobileM').hide();
            $('#divMBTransactionIDM').hide();
            $('#ModeOFPaymentM').html(ModeOFPayment);
        }
        else {
            $('#divCardTypeM').hide();
            $('#divCreditCardM').hide();
            $('#divBankNameM').hide();
            $('#divChequeNoM').hide();
            $('#divBCashNo').hide();
            $('#divMBBankM').hide();
            $('#divMBMobileM').hide();
            $('#ModeOFPaymentM').html();
            $('#divMBTransactionIDM').hide();
        }

        ///////////////////////////////////////////////////////////////////


        $('#CustomerZone').html(CustomerZone);
        $('#CustomerCountry').html(CustomerCountry);


        $('#Autoserial').html(autoserial);
        $('#ManualSerial').html(manualSerial);
        $('#McdDate').html(mcdDate);
        //$('#StationOffice').html(stationOffice); 
        $('#CustomerName').html(CustomerName);
        $('#CorporateID').html(corporateID);
        $('#CustomerMobile').html(CusMobile);
        $('#CustomerEmail').html(CusEmail);
        $('#CustomerAddress').html(CusAddress);
        //$('#CollectionPurpose').html(collectionPurpose);
        $('#PNR').html(PNR);
        $('#FEES').html(fees);
        $('#FlightNO').html(flightNo);
        $('#FlightDATE').html(flightDate);
        $('#QuantityM').html(Quantity);
        $('#WeightM').html(weight);
        $('#TagModal').html(tagNo);
        $('#ReferrenceM').html(referrence);
        $('#CargoReceiverM').html(cargoReceiver);
        $('#BusNOMo').html(busNo);
        $('#BusTime').html(busStartTime);

        $('#OtherRemark').html(otherRemarks);

        var purposeID = $("#ddlPurposeOfCollection").val()
        if (purposeID == "bus_tkt") {
            $('#RouteStartM').html(routeStartText);
            $('#RouteEndM').html(routeEndText);
        }
        else {
            var startIDroute = $("#ddlRouteStart").val()
            var endIDroute = $("#ddlRouteEnd").val()
            if (startIDroute == "sl5") {
                $('#RouteStartM').html("");
            }
            else {
                $('#RouteStartM').html(routeStartDDL);
            }

            if (endIDroute == "sl6") {
                $('#RouteEndM').html("");
            }
            else {
                $('#RouteEndM').html(routeEndDDL);
            }
        }

        ////////////////////////////////////////////////

        var cardTypeID = $("#ddlCardType").val()
        if (cardTypeID == 'sl3') {
            $('#CardTypeM').html("");
        }
        else {
            $('#CardTypeM').html(cardType);
        }
        ////////////////////////////////////////////////////////////
        $('#CreditCard').html(cardNo);
        if (cardNo == "-XXXX-XXXX-") {
            $('#CreditCard').html("");
        }
        else {
            $('#CreditCard').html(cardNo);
        }
        /////////////////////////////////////////////////////

        var paymentModeID = $("#ddlModeOfPayment").val()

        if (paymentModeID == "card") {
            if (cardNO1 == "") {
                alert("Please Enter 1st four digits of Credit Card")

            }
            if (cardNo4 == "") {
                alert("Please Enter last 4 digits of Credit Card")
            }
        }

        ////////////////////////////////////////

        $('#BankName').html(bankName);
        //$('#CreditCard').html(cardNo);
        $('#ChequeNoM').html(chequeNo);
        $('#BCashNo').html(bcashMobile);
        $('#MBBankName').html(MBbank);
        $('#MBTransactionIDM').html(TracsactionID);
        $('#MBMobile').html(MBmobile);
        $('#CurrencyM').html(currency);
        $('#AmountM').html(amount);
        $('#WaiverM').html(waiver);
        $('#TaxM').html(tax);
        $('#PaidAmountM').html(paidAmount);
        $('#AmountInWordM').html(amountInWord);
        $('#LastRemarksM').html(remarks);
    });

    $("#rbAllCustomer").click(function () {
        $("#divCustomerMobile").hide();
        $("#divCustomerName").hide();
    });

    $("#rbSingleCustomer").click(function () {
        $("#divCustomerMobile").show();
        $("#divCustomerName").show();
    });

    $('#txtFees').on('input', function () {

        var purposeID = $("#ddlPurposeOfCollection").val()
        if (purposeID == "ebt") {
            var tax = $(this).val();
            var weight = parseInt($('#txtWeight').val(), 10);
            var amount = (tax * weight);
            $("#txtAmount").attr("disabled", "disabled");
            $('#txtAmount').val(amount);
            $('#txtWaiver').val(0);
            $('#txtTax').val(0);
            $('#txtPaidAmount').val(amount);
            $('#hdAmountAuto').val(parseInt($('#txtAmount').val(), 10));


        }
        else if (purposeID == "cargo") {
            var tax = $(this).val();
            var weight = parseInt($('#txtWeight').val(), 10);
            var amount = (tax * weight);
            $("#txtAmount").attr("disabled", "disabled");
            $('#txtAmount').val(amount);
            $('#txtWaiver').val(0);
            $('#txtTax').val(0);
            $('#txtPaidAmount').val(amount);
            $('#hdAmountAuto').val(parseInt($('#txtAmount').val(), 10));
        }
            //else if (purposeID == "bus_tkt") {
            //    var tax = $(this).val();
            //    var weight = parseInt($('#txtWeight').val(), 10);
            //    var amount = (tax * weight);
            //    $("#txtAmount").attr("disabled", "disabled");
            //    $('#txtAmount').val(amount);
            //    $('#txtWaiver').val(0);
            //    $('#txtTax').val(0);
            //    $('#txtPaidAmount').val(amount);
            //    $('#hdAmountAuto').val(parseInt($('#txtAmount').val(), 10));
            //}
        else {
        }
    });
    $('#txtWeight').on('input', function () {

        var purposeID = $("#ddlPurposeOfCollection").val()
        if (purposeID == "ebt") {
            var weight = $(this).val();
            var tax = parseInt($('#txtFees').val(), 10);
            var amount = (tax * weight);
            $("#txtAmount").attr("disabled", "disabled");
            $('#txtAmount').val(amount);
            $('#txtWaiver').val(0);
            $('#txtTax').val(0);
            $('#txtPaidAmount').val(amount);
            $('#hdAmountAuto').val(parseInt($('#txtAmount').val(), 10));
        }
        else if (purposeID == "cargo") {
            var weight = $(this).val();
            var tax = parseInt($('#txtFees').val(), 10);
            var amount = (tax * weight);
            $("#txtAmount").attr("disabled", "disabled");
            $('#txtAmount').val(amount);
            $('#txtWaiver').val(0);
            $('#txtTax').val(0);
            $('#txtPaidAmount').val(amount);
            $('#hdAmountAuto').val(parseInt($('#txtAmount').val(), 10));
        }
        else {
        }
    });
    $('#txtPassengerNo').on('input', function () {

        var purposeID = $("#ddlPurposeOfCollection").val()
        if (purposeID == "bus_tkt") {
            var passenger = $(this).val();
            var fare = parseInt($('#txtBusFare').val(), 10);
            var amount = (fare * passenger);
            $("#txtAmount").attr("disabled", "disabled");
            $('#txtAmount').val(amount);
            $('#txtWaiver').val(0);
            $('#txtTax').val(0);
            $('#txtPaidAmount').val(amount);
            $('#hdAmountAuto').val(parseInt($('#txtAmount').val(), 10));
        }
    });
    $('#txtBusFare').on('input', function () {

        var purposeID = $("#ddlPurposeOfCollection").val()
        if (purposeID == "bus_tkt") {
            var fare = $(this).val();
            var passenger = parseInt($('#txtPassengerNo').val(), 10);
            var amount = (fare * passenger);
            $("#txtAmount").attr("disabled", "disabled");
            $('#txtAmount').val(amount);
            $('#txtWaiver').val(0);
            $('#txtTax').val(0);
            $('#txtPaidAmount').val(amount);
            $('#hdAmountAuto').val(parseInt($('#txtAmount').val(), 10));
        }
    });

}

function GetddlModeOfPayment() {
    var paymentModeID = $("#ddlModeOfPayment").val()

    if (paymentModeID == "cash") {

        $('#divBankCardType').hide();
        $('#divCardNoFull').hide();
        $('#divChequeNoFull').hide();
        $('#divBcashMobileFull').hide();
        $('#divMBbankMobile').hide();

        $('#divCardType').hide();
        $('#divCardNo').hide();
        $('#divBankName').hide();
        $('#divChequeNo').hide();
        $('#divBcashMobile').hide();
        $('#divMBbank').hide();
        $('#divMBMobile').hide();
        $('#divTransactionID').hide();
        $('#lblRedStarTransaction').hide();
    }
    else if (paymentModeID == "card") {

        $('#divBankCardType').show();
        $('#divCardNoFull').show();
        $('#divChequeNoFull').hide();
        $('#divBcashMobileFull').hide();
        $('#divMBbankMobile').hide();

        $('#divCardNo').show();
        $('#divCardType').show();
        $('#divBankName').show();
        $('#divChequeNo').hide();
        $('#divBcashMobile').hide();
        $('#divMBbank').hide();
        $('#divMBMobile').hide();
        $('#divTransactionID').show();
        $('#lblRedStarTransaction').hide();
    }
    else if (paymentModeID == "cheque") {
        $('#divBankCardType').show();
        $('#divCardNoFull').hide();
        $('#divChequeNoFull').show();
        $('#divBcashMobileFull').hide();
        $('#divMBbankMobile').hide();

        $('#divCardNo').hide();
        $('#divBankName').show();
        $('#divChequeNo').show();
        $('#divBcashMobile').hide();
        $('#divMBbank').hide();
        $('#divMBMobile').hide();
        $('#divCardType').hide();
        $('#divTransactionID').hide();
        $('#lblRedStarTransaction').hide();
    }
    else if (paymentModeID == "bCash") {

        $('#divBankCardType').hide();
        $('#divCardNoFull').hide();
        $('#divChequeNoFull').hide();
        $('#divBcashMobileFull').show();
        $('#divMBbankMobile').hide();

        $('#divCardNo').hide();
        $('#divBankName').hide();
        $('#divChequeNo').hide();
        $('#divBcashMobile').show();
        $('#divMBbank').hide();
        $('#divMBMobile').hide();
        $('#divCardType').hide();
        $('#divTransactionID').hide();
        $('#lblRedStarTransaction').hide();
    }
    else if (paymentModeID == "m_banking") {

        $('#divBankCardType').hide();
        $('#divCardNoFull').hide();
        $('#divChequeNoFull').hide();
        $('#divBcashMobileFull').hide();
        $('#divMBbankMobile').show();

        $('#divCardNo').hide();
        $('#divBankName').hide();
        $('#divChequeNo').hide();
        $('#divBcashMobile').hide();
        $('#divMBbank').show();
        $('#divMBMobile').show();
        $('#divCardType').hide();
        $('#divTransactionID').show();
        $('#lblRedStarTransaction').show();
    }
    else if (paymentModeID == "invoice") {

        $('#divBankCardType').hide();
        $('#divCardNoFull').hide();
        $('#divChequeNoFull').hide();
        $('#divBcashMobileFull').hide();
        $('#divMBbankMobile').hide();

        $('#divCardNo').hide();
        $('#divBankName').hide();
        $('#divChequeNo').hide();
        $('#divBcashMobile').hide();
        $('#divMBbank').hide();
        $('#divMBMobile').hide();
        $('#divCardType').hide();
        $('#divTransactionID').hide();
        $('#lblRedStarTransaction').hide();
    }
    else if (paymentModeID == "others") {
        $('#divBankCardType').hide();
        $('#divCardNoFull').hide();
        $('#divChequeNoFull').hide();
        $('#divBcashMobileFull').hide();
        $('#divMBbankMobile').hide();

        $('#divCardNo').hide();
        $('#divBankName').hide();
        $('#divChequeNo').hide();
        $('#divBcashMobile').hide();
        $('#divMBbank').hide();
        $('#divMBMobile').hide();
        $('#divCardType').hide();
        $('#divTransactionID').hide();
        $('#lblRedStarTransaction').hide();
    }
    else {
        $('#divBankCardType').hide();
        $('#divCardNoFull').hide();
        $('#divChequeNoFull').hide();
        $('#divBcashMobileFull').hide();
        $('#divMBbankMobile').hide();

        $('#divCardNo').hide();
        $('#divBankName').hide();
        $('#divChequeNo').hide();
        $('#divBcashMobile').hide();
        $('#divMBbank').hide();
        $('#divMBMobile').hide();
        $('#divCardType').hide();
        $('#divTransactionID').hide();
        $('#lblRedStarTransaction').hide();
    }
}

function GetddlPurposeOfCollection() {
    var purposeID = $("#ddlPurposeOfCollection").val()
    $('#divSelectRoute').show();
    if (purposeID == "tkt_Issu") {

        $('#divPnrFees').show();
        $('#divPNR').show();
        $('#divFees').hide();
        $('#divBusNoTime').hide();
        $('#divPurposeRemarksHead').hide();
        $('#divFlightNoDate').hide();
        $('#divQuantityWeight').hide();
        $('#divTagReference').hide();
        $('#divReceiverHead').hide();
        $('#divflightNo').hide();
        $('#divFlightDate').hide();
        $('#divQuantity').hide();
        $('#divWeight').hide();
        $('#divTagNo').hide();
        $('#divReferenceNo').hide();
        $('#divBusNo').hide();
        $('#divBusStartTime').hide();
        $('#divRemarksPurpose').hide();
        //$('#divCargoReceiver').hide();

        $('#divSelectRoute').hide();
        $('#divRouteDropDownList').show();
        $('#divRouteTextBoxes').hide();

        $('#divRpoteStartText').hide();
        $('#divRouteEndText').hide();

        $('#divRpoteStartDD').show();
        $('#divRouteEndDD').show();

        $("#txtWeight").val("");
        $('#txtAmount').val("");
        $('#txtWaiver').val("");
        $('#txtTax').val("");
        $('#txtPaidAmount').val("");
        $('#txtFees').val("");
        $("#txtAmount").removeAttr("disabled");
        $('#lblRedStar').show();
        $('#lblRedStarr').show();
        $("#ddlRouteStart").val("sl5");
        $("#ddlRouteEnd").val("sl6");

        $('#selectStrtEndRoute').removeAttr('checked');
        $('#selectTagReffNo').removeAttr('checked');
        $('#selectReceiverInfo').removeAttr('checked');
        $('#divBusPassengerFare').hide();

    }
    else if (purposeID == "tkt_Exchange") {

        $('#divPnrFees').show();
        $('#divPNR').show();
        $('#divFees').hide();
        $('#divBusNoTime').hide();
        $('#divPurposeRemarksHead').hide();
        $('#divFlightNoDate').hide();
        $('#divQuantityWeight').hide();
        $('#divTagReference').hide();
        $('#divReceiverHead').hide();
        $('#divflightNo').hide();
        $('#divFlightDate').hide();
        $('#divQuantity').hide();
        $('#divWeight').hide();
        $('#divTagNo').hide();
        $('#divReferenceNo').hide();
        $('#divBusNo').hide();
        $('#divBusStartTime').hide();
        $('#divRemarksPurpose').hide();
        //$('#divCargoReceiver').hide();
        $('#divSelectRoute').show();
        $('#divRouteDropDownList').hide();
        $('#divRouteTextBoxes').hide();
        $('#divRpoteStartText').hide();
        $('#divRouteEndText').hide();

        $('#divRpoteStartDD').show();
        $('#divRouteEndDD').show();

        $("#txtWeight").val("");
        $('#txtAmount').val("");
        $('#txtWaiver').val("");
        $('#txtTax').val("");
        $('#txtPaidAmount').val("");
        $('#txtFees').val("");
        $("#txtAmount").removeAttr("disabled");
        $('#lblRedStar').hide();
        $('#lblRedStarr').hide();
        $("#ddlRouteStart").val("sl5");
        $("#ddlRouteEnd").val("sl6");
        $('#divBusPassengerFare').hide();

        $('#selectStrtEndRoute').removeAttr('checked');
        $('#selectTagReffNo').removeAttr('checked');
        $('#selectReceiverInfo').removeAttr('checked');
    }
    else if (purposeID == "mail_courier") {
        $('#divPnrFees').hide();
        $('#divBusNoTime').hide();
        $('#divPurposeRemarksHead').hide();
        $('#divFlightNoDate').show();
        $('#divQuantityWeight').show();
        $('#divTagReference').hide();
        $('#divReceiverHead').hide();
        $('#divSelectRoute').hide();
        $('#divRouteDropDownList').show();
        $('#divRouteTextBoxes').hide();

        $('#divPNR').hide();
        $('#divFees').hide();
        $('#divflightNo').show();
        $('#divFlightDate').show();
        $('#divQuantity').show();
        $('#divWeight').show();
        $('#divTagNo').show();
        $('#divReferenceNo').show();
        $('#divBusNo').hide();
        $('#divBusStartTime').hide();
        $('#divRemarksPurpose').hide();
        //$('#divCargoReceiver').show();
        $('#divRpoteStartText').hide();
        $('#divRouteEndText').hide();

        $('#divRpoteStartDD').show();
        $('#divRouteEndDD').show();

        $("#txtWeight").val("");
        $('#txtAmount').val("");
        $('#txtWaiver').val("");
        $('#txtTax').val("");
        $('#txtPaidAmount').val("");
        $('#txtFees').val("");
        $("#txtAmount").removeAttr("disabled");
        $('#lblRedStar').show();
        $('#lblRedStarr').show();
        $("#ddlRouteStart").val("sl5");
        $("#ddlRouteEnd").val("sl6");
        $('#divBusPassengerFare').hide();

        $('#selectStrtEndRoute').removeAttr('checked');
        $('#selectTagReffNo').removeAttr('checked');
        $('#selectReceiverInfo').removeAttr('checked');
    }
    else if (purposeID == "ebt") {
        $('#divPnrFees').show();
        $('#divBusNoTime').hide();
        $('#divPurposeRemarksHead').hide();
        $('#divFlightNoDate').show();
        $('#divQuantityWeight').show();
        $('#divTagReference').hide();
        $('#divReceiverHead').hide();
        $('#divSelectRoute').show();
        $('#divRouteDropDownList').hide();
        $('#divRouteTextBoxes').hide();

        $('#divPNR').show();
        $('#divFees').show();
        $('#divflightNo').show();
        $('#divFlightDate').show();
        $('#divQuantity').hide();
        $('#divWeight').show();
        $('#divTagNo').show();
        $('#divReferenceNo').show();
        $('#divBusNo').hide();
        $('#divBusStartTime').hide();
        $('#divRemarksPurpose').hide();
        //$('#divCargoReceiver').hide();
        $('#divRpoteStartText').hide();
        $('#divRouteEndText').hide();

        $('#divRpoteStartDD').show();
        $('#divRouteEndDD').show();

        $("#txtWeight").val("");
        $('#txtAmount').val("");
        $('#txtWaiver').val("");
        $('#txtTax').val("");
        $('#txtPaidAmount').val("");
        $('#txtFees').val("");
        $("#txtAmount").removeAttr("disabled");
        $('#lblRedStar').hide();
        $('#lblRedStarr').hide();
        $("#ddlRouteStart").val("sl5");
        $("#ddlRouteEnd").val("sl6");
        $('#divBusPassengerFare').hide();

        $('#selectStrtEndRoute').removeAttr('checked');
        $('#selectTagReffNo').removeAttr('checked');
        $('#selectReceiverInfo').removeAttr('checked');

    }
    else if (purposeID == "cargo") {


        $('#divPnrFees').show();
        $('#divBusNoTime').hide();
        $('#divPurposeRemarksHead').hide();
        $('#divFlightNoDate').show();
        $('#divQuantityWeight').show();
        $('#divTagReference').hide();
        $('#divReceiverHead').hide();
        $('#divSelectRoute').show();
        $('#divRouteDropDownList').hide();
        $('#divRouteTextBoxes').hide();

        $('#divPNR').hide();
        $('#divFees').show();
        $('#divflightNo').show();
        $('#divFlightDate').show();
        $('#divQuantity').hide();
        $('#divWeight').show();
        $('#divTagNo').show();
        $('#divReferenceNo').show();
        $('#divBusNo').hide();
        $('#divBusStartTime').hide();
        $('#divRemarksPurpose').hide();
        //$('#divCargoReceiver').show();
        $('#divRpoteStartText').hide();
        $('#divRouteEndText').hide();

        $('#divRpoteStartDD').show();
        $('#divRouteEndDD').show();

        $("#txtWeight").val("");
        $('#txtAmount').val("");
        $('#txtWaiver').val("");
        $('#txtTax').val("");
        $('#txtPaidAmount').val("");
        $('#txtFees').val("");
        $("#txtAmount").removeAttr("disabled");
        $('#lblRedStar').hide();
        $('#lblRedStarr').hide();
        $("#ddlRouteStart").val("sl5");
        $("#ddlRouteEnd").val("sl6");
        $('#divBusPassengerFare').hide();

        $('#selectStrtEndRoute').removeAttr('checked');
        $('#selectTagReffNo').removeAttr('checked');
        $('#selectReceiverInfo').removeAttr('checked');

    }
    else if (purposeID == "bus_tkt") {
        $('#divPnrFees').show();
        $('#divBusNoTime').show();
        $('#divPurposeRemarksHead').hide();
        $('#divFlightNoDate').hide();
        $('#divQuantityWeight').hide();
        $('#divTagReference').hide();
        $('#divReceiverHead').hide();
        $('#divSelectRoute').hide();
        $('#divRouteDropDownList').hide();
        $('#divRouteTextBoxes').show();

        $('#divPNR').hide();
        $('#divFees').hide();
        $('#divflightNo').hide();
        $('#divFlightDate').hide();
        $('#divQuantity').hide();
        $('#divWeight').hide();
        $('#divTagNo').hide();
        $('#divReferenceNo').hide();
        $('#divBusNo').show();
        $('#divBusStartTime').show();
        $('#divRemarksPurpose').hide();
        //$('#divCargoReceiver').hide();

        $('#divRpoteStartText').show();
        $('#divRouteEndText').show();

        $('#divRpoteStartDD').hide();
        $('#divRouteEndDD').hide();

        $("#txtWeight").val("");
        $('#txtAmount').val("");
        $('#txtWaiver').val("");
        $('#txtTax').val("");
        $('#txtPaidAmount').val("");
        $('#txtFees').val("");
        $("#txtAmount").removeAttr("disabled");
        $('#lblRedStar').hide();
        $('#lblRedStarr').hide();
        $("#ddlRouteStart").val("sl5");
        $("#ddlRouteEnd").val("sl6");
        $('#divBusPassengerFare').show();

        $('#selectStrtEndRoute').removeAttr('checked');
        $('#selectTagReffNo').removeAttr('checked');
        $('#selectReceiverInfo').removeAttr('checked');

    }
    else if (purposeID == "other") {

        $('#divPnrFees').hide();
        $('#divBusNoTime').hide();
        $('#divPurposeRemarksHead').show();
        $('#divFlightNoDate').hide();
        $('#divQuantityWeight').hide();
        $('#divTagReference').hide();
        $('#divReceiverHead').hide();
        $('#divSelectRoute').show();
        $('#divRouteDropDownList').hide();
        $('#divRouteTextBoxes').hide();

        $('#divPNR').hide();
        $('#divFees').hide();
        $('#divflightNo').hide();
        $('#divFlightDate').hide();
        $('#divQuantity').hide();
        $('#divWeight').hide();
        $('#divTagNo').hide();
        $('#divReferenceNo').hide();
        $('#divBusNo').hide();
        $('#divBusStartTime').hide();
        $('#divRemarksPurpose').show();
        //$('#divCargoReceiver').hide();
        $('#divRpoteStartText').hide();
        $('#divRouteEndText').hide();

        $('#divRpoteStartDD').show();
        $('#divRouteEndDD').show();

        $("#txtWeight").val("");
        $('#txtAmount').val("");
        $('#txtWaiver').val("");
        $('#txtTax').val("");
        $('#txtPaidAmount').val("");
        $('#txtFees').val("");
        $("#txtAmount").removeAttr("disabled");
        $('#lblRedStar').hide();
        $('#lblRedStarr').hide();
        $("#ddlRouteStart").val("sl5");
        $("#ddlRouteEnd").val("sl6");
        $('#divBusPassengerFare').hide();

        $('#selectStrtEndRoute').removeAttr('checked');
        $('#selectTagReffNo').removeAttr('checked');
        $('#selectReceiverInfo').removeAttr('checked');
    }
    else {

        $('#divPnrFees').hide();
        $('#divBusNoTime').hide();
        $('#divPurposeRemarksHead').hide();
        $('#divFlightNoDate').hide();
        $('#divQuantityWeight').hide();
        $('#divTagReference').hide();
        $('#divReceiverHead').hide();
        $('#divSelectRoute').hide();
        $('#divRouteDropDownList').hide();
        $('#divRouteTextBoxes').hide();

        $('#divPNR').hide();
        $('#divFees').hide();
        $('#divflightNo').hide();
        $('#divFlightDate').hide();
        $('#divQuantity').hide();
        $('#divWeight').hide();
        $('#divTagNo').hide();
        $('#divReferenceNo').hide();
        $('#divBusNo').hide();
        $('#divBusStartTime').hide();
        $('#divRemarksPurpose').hide();
        //$('#divCargoReceiver').hide();
        $('#divRpoteStartText').hide();
        $('#divRouteEndText').hide();

        $('#divRpoteStartDD').show();
        $('#divRouteEndDD').show();

        $("#txtWeight").val("");
        $('#txtAmount').val("");
        $('#txtWaiver').val("");
        $('#txtTax').val("");
        $('#txtPaidAmount').val("");
        $('#txtFees').val("");
        $("#txtAmount").removeAttr("disabled");
        $('#lblRedStar').hide();
        $('#lblRedStarr').hide();
        $("#ddlRouteStart").val("sl5");
        $("#ddlRouteEnd").val("sl6");
        $('#divBusPassengerFare').hide();

        $('#selectStrtEndRoute').removeAttr('checked');
        $('#selectTagReffNo').removeAttr('checked');
        $('#selectReceiverInfo').removeAttr('checked');
    }
}

function GetDepositModewiseField() {
    var purposeID = $("#ddlDepositMode").val()

    if (purposeID == "external") {

        $('#divDepositAmount').show();
        $('#divRemarks').show();
        $('#divBankName').show();
        $('#divBankBranch').show();
        $('#divDepositSlipNo').show();
        $('#divDepositDate').show();
        $('#divDepositBy').show();
        $('#divDepositBankCharge').show();

        $('#divReceivedBy').hide();
        $('#divReceiverPhone').hide();
        $('#divReceiverEmpID').hide();
        $('#divReceivedDate').hide();

        $('#txtDepositedAmount').val("");
        $('#txtRemarks').val("");
        $('#txtBankname').val("");
        $('#txtBankBranch').val("");
        $('#txtDepositSlipNo').val("");
        $('#txtDepositDate').val("");
        $('#txtDepositBy').val("");
        $('#txtBankCharge').val("");
        $('#txtReceivedby').val("");
        $('#txtReceiverPhone').val("");
        $('#txtReceiverEmpID').val("");
        $('#txtReceiveDate').val("");

    }
    else //if (purposeID == "internal") 
    {
        $('#divReceivedBy').show();
        $('#divReceiverPhone').show();
        $('#divReceiverEmpID').show();
        $('#divReceivedDate').show();
        $('#divDepositAmount').show();
        $('#divRemarks').show();

        $('#divBankName').hide();
        $('#divBankBranch').hide();
        $('#divDepositSlipNo').hide();
        $('#divDepositDate').hide();
        $('#divDepositBy').hide();
        $('#divDepositBankCharge').hide();

        $('#txtReceivedby').val("");
        $('#txtReceiverPhone').val("");
        $('#txtReceiverEmpID').val("");
        $('#txtReceiveDate').val("");
        $('#txtDepositedAmount').val("");
        $('#txtRemarks').val("");
        $('#txtBankname').val("");
        $('#txtBankBranch').val("");
        $('#txtDepositSlipNo').val("");
        $('#txtDepositDate').val("");
        $('#txtDepositBy').val("");
        $('#txtBankCharge').val("");
    }
    //else {
    //    $('#divReceivedBy').hide();
    //    $('#divReceiverPhone').hide();
    //    $('#divReceiverEmpID').hide();
    //    $('#divReceivedDate').hide();
    //    $('#divDepositAmount').hide();
    //    $('#divRemarks').hide();
    //    $('#divBankName').hide();
    //    $('#divBankBranch').hide();
    //    $('#divDepositSlipNo').hide();
    //    $('#divDepositDate').hide();
    //    $('#divDepositBy').hide();
    //    $('#divDepositBankCharge').hide();

    //    $('#txtReceivedby').val("");
    //    $('#txtReceiverPhone').val("");
    //    $('#txtReceiverEmpID').val("");
    //    $('#txtReceiveDate').val("");
    //    $('#txtDepositedAmount').val("");
    //    $('#txtRemarks').val("");
    //    $('#txtBankname').val("");
    //    $('#txtBankBranch').val("");
    //    $('#txtDepositSlipNo').val("");
    //    $('#txtDepositDate').val("");
    //    $('#txtDepositBy').val("");
    //    $('#txtBankCharge').val("");
    //}
}

function GetCheckBoxSelect() {
    if ($('#checkMeOut').prop('checked')) {
        $('#divManualSerial').show();
    }
    else {
        $('#divManualSerial').hide();
    }
}

function GetCorporateIDSelect() {
    if ($('#checkCorporateID').prop('checked')) {
        $('#divCustomerCorporateID').show();
    }
    else {
        $('#divCustomerCorporateID').hide();
    }
}

function GetTagReffTextBox() {
    if ($('#selectTagReffNo').prop('checked')) {
        $('#divTagReference').show();
    }
    else {
        $('#divTagReference').hide();
    }
}

function GetTagReffEBTtextBox() {
    if ($('#selectTagReffNoEBT').prop('checked')) {
        $('#divTagReference').show();
    }
    else {
        $('#divTagReference').hide();
    }
}

function GetReceiverInfoTextBox() {
    if ($('#selectReceiverInfo').prop('checked')) {
        $('#divReceiverHead').show();
        $('#divCargoReceiver').show();
    }
    else {
        $('#divReceiverHead').hide();
        $('#divCargoReceiver').hide();
    }
}

function GetCurrencyDropDown() {
    if ($('#selectCurrency').prop('checked')) {
        $('#divAmountCurrency').show();
    }
    else {
        $('#divAmountCurrency').hide();
    }
}

function GetFinalRemarksTextBox() {
    if ($('#addFinalRemarks').prop('checked')) {
        $('#divFinalComments').show();
    }
    else {
        $('#divFinalComments').hide();
    }
}

function GetMCDStatusRadioButton() {
    if ($('#chkStatus').prop('checked')) {
        $('#divMCDStatus').show();
    }
    else {
        $('#divMCDStatus').hide();
    }
}

function GetMCDSerialTextBox() {
    if ($('#chkSerial').prop('checked')) {
        $('#divMCDSerial').show();
    }
    else {
        $('#divMCDSerial').hide();
    }
}

function GetDateRangeDiv() {
    if ($('#chkDateRange').prop('checked')) {
        $('#divStartEndDateRange').show();
    }
    else {
        $('#divStartEndDateRange').hide();
    }
}

function GetCustomerEmailSelect() {
    if ($('#checkCustomerEmail').prop('checked')) {
        $('#divCustomerEmail').show();
    }
    else {
        $('#divCustomerEmail').hide();
    }
}

function GetCustomerAddressBox() {
    if ($('#checkCustomerAddress').prop('checked')) {
        $('#divCustAddress').show();
    }
    else {
        $('#divCustAddress').hide();
    }
}

function GetstartEndRouteDropDown() {
    if ($('#selectStrtEndRoute').prop('checked')) {
        $('#divRouteDropDownList').show();
    }
    else {
        $('#divRouteDropDownList').hide();
    }
}

function GetPaidAmountInWord() {
    var textValue = $('#txtPaidAmount').val();
    var result = toWords(textValue);
    $('#lblAmountInWord').text(result);
}

function CheckforSameENd() {
    var startID = $("#ddlRouteStart").val()
    var endID = $("#ddlRouteEnd").val()
    if (startID == endID) {
        alert("Select Correct Start Route")
        $("#ddlRouteStart").val("sl5");
    }
}

function CheckforSameBusENd() {
    var startID = $("#ddlBusStartRoute").val()
    var endID = $("#ddlBusEndRoute").val()
    if (startID == endID) {
        alert("Select Correct Start Route")
        $("#ddlBusStartRoute").val("sl7");
    }
}

function CheckforSameStart() {
    var startID = $("#ddlRouteStart").val()
    var endID = $("#ddlRouteEnd").val()
    if (startID == endID) {
        alert("Select Correct End Route")
        $("#ddlRouteEnd").val("sl6");
    }
}

function CheckforSameBusStart() {
    var startID = $("#ddlBusStartRoute").val()
    var endID = $("#ddlBusEndRoute").val()
    if (startID == endID) {
        alert("Select Correct End Route")
        $("#ddlBusEndRoute").val("sl8");
    }
}

function toWords(s) {
    var th = ['', 'Thousand', 'Million', 'Billion', 'Trillion'];
    var dg = ['Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine']; var tn = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen']; var tw = ['Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    s = s.toString(); s = s.replace(/[\, ]/g, '');
    if (s != parseFloat(s)) return 'Not a number';
    var x = s.indexOf('.');
    if (x == -1) x = s.length;
    if (x > 15)
        return 'too big';
    var n = s.split('');
    var str = '';
    var sk = 0;
    for (var i = 0; i < x; i++) {
        if ((x - i) % 3 == 2) {
            if (n[i] == '1') { str += tn[Number(n[i + 1])] + ' '; i++; sk = 1; }
            else if (n[i] != 0) { str += tw[n[i] - 2] + ' '; sk = 1; }
        }
        else if (n[i] != 0)
        { str += dg[n[i]] + ' '; if ((x - i) % 3 == 0) str += 'Hundred '; sk = 1; }
        if ((x - i) % 3 == 1)
        { if (sk) str += th[(x - i - 1) / 3] + ' '; sk = 0; }
    } if (x != s.length)
    { var y = s.length; str += 'point '; for (var i = x + 1; i < y; i++) str += dg[n[i]] + ' '; }
    return str.replace(/\s+/g, ' ');
}

